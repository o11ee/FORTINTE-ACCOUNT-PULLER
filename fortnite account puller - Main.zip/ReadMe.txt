this is a fortnite account puller.

[download link]

---------------
---------------

if need help, add 69LlLl#7431 on discord.

---------------
---------------

[READ!!!!]

THIS IS FOR EDUCATION PEOPLE ONLY!!!
----
i'm not responsible to the damage you can do!!

--------


you can pull peoples fortnite account.

this is illegal so take it chill with it please.

------------------

[LOGIN INFORMATION]

username: 69

---------

password: 69



